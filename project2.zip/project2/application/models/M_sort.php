<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_sort extends CI_Model {



}
